let hours_worked = [80; 80; 80]
