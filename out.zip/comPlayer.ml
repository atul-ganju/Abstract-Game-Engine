
(** [turn game] produces a computer generated turn command. *)
let turn game = ""